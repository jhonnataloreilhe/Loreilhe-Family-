// script.js
// Navegação móvel e realce de seção ativa
const navToggle = document.querySelector('.nav-toggle');
const navList = document.querySelector('.nav-list');

navToggle?.addEventListener('click', () => {
  navList.classList.toggle('show');
});

// Fechar menu ao clicar em um link
navList?.addEventListener('click', (e) => {
  if (e.target.tagName === 'A') navList.classList.remove('show');
});

// Realce de link ativo com IntersectionObserver
const sections = document.querySelectorAll('main .section');
const links = document.querySelectorAll('.nav-list a');

const byId = (id) => [...links].find((a) => a.getAttribute('href') === `#${id}`);

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      const link = byId(entry.target.id);
      if (!link) return;
      if (entry.isIntersecting) {
        links.forEach((l) => l.classList.remove('active'));
        link.classList.add('active');
      }
    });
  },
  { rootMargin: '-40% 0px -50% 0px', threshold: 0.01 }
);

sections.forEach((s) => observer.observe(s));

// Formulário (validação simples e feedback)
const form = document.getElementById('contact-form');
const status = document.querySelector('.form-status');

form?.addEventListener('submit', (e) => {
  e.preventDefault();
  const data = new FormData(form);
  const nome = data.get('nome')?.toString().trim();
  const email = data.get('email')?.toString().trim();
  const mensagem = data.get('mensagem')?.toString().trim();

  // Validação básica
  if (!nome || !email || !mensagem) {
    status.textContent = 'Preencha todos os campos.';
    status.style.color = getComputedStyle(document.documentElement).getPropertyValue('--danger');
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    status.textContent = 'Informe um email válido.';
    status.style.color = getComputedStyle(document.documentElement).getPropertyValue('--danger');
    return;
  }

  // Simulação de envio
  status.textContent = 'Mensagem enviada com sucesso. Obrigado por contribuir!';
  status.style.color = getComputedStyle(document.documentElement).getPropertyValue('--success');
  form.reset();

  // Dica visual temporária
  setTimeout(() => {
    status.textContent = '';
    status.style.color = '';
  }, 5000);
});
